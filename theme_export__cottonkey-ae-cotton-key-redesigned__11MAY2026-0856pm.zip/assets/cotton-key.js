/* ============================================================
   COTTON KEY — VISUAL ENHANCEMENT JS v3.0
   Handles: loader, header behavior, scroll reveal, 
   parallax, gallery, accordion, cart drawer, mobile menu.
   Does NOT replace any Shopify cart/product/checkout logic.
   ============================================================ */

(function () {
  'use strict';

  if (window.CottonKeyInit) return;
  window.CottonKeyInit = true;

  const CK = {

    lang: document.documentElement.lang || 'en',

    init() {
      this.loader();
      this.header();
      this.mobileMenu();
      this.scrollReveal();
      this.parallax();
      this.gallery();
      this.accordion();
      this.cartDrawer();
      this.cartCount();
    },

    // ── LOADER ──────────────────────────────────────────────
    loader() {
      const loader = document.getElementById('ck-loader');
      if (!loader) return;
      if (document.documentElement.classList.contains('shopify-design-mode')) {
        loader.style.display = 'none';
        return;
      }

      const hero = document.querySelector('.ck-hero');
      const dismiss = () => {
        loader.classList.add('loaded');
        hero && hero.classList.add('loaded');
      };

      if (document.readyState === 'complete') {
        setTimeout(dismiss, 600);
      } else {
        window.addEventListener('load', () => setTimeout(dismiss, 800));
      }
      setTimeout(dismiss, 3200); // hard fallback
    },

    // ── HEADER SCROLL + HERO MODE ────────────────────────────
    header() {
      const header = document.querySelector('.ck-header');
      if (!header) return;

      const hero = document.querySelector('.ck-hero');
      let lastScrollY = 0;

      const update = () => {
        const y = window.scrollY;
        header.classList.toggle('scrolled', y > 40);

        if (hero) {
          const heroBottom = hero.offsetHeight;
          header.classList.toggle('hero-mode', y < heroBottom - 80 && y < heroBottom);
        }

        lastScrollY = y;
      };

      // Init hero mode
      if (hero) header.classList.add('hero-mode');

      window.addEventListener('scroll', update, { passive: true });
      update();
    },

    // ── MOBILE MENU ──────────────────────────────────────────
    mobileMenu() {
      const menuBtn = document.querySelector('.ck-header__menu-btn');
      const menu    = document.querySelector('.ck-mobile-menu');
      const close   = document.querySelector('.ck-mobile-menu__close');

      if (!menuBtn || !menu) return;

      const open  = () => { menu.classList.add('open'); document.body.style.overflow = 'hidden'; menuBtn.setAttribute('aria-expanded', 'true'); };
      const shut  = () => { menu.classList.remove('open'); document.body.style.overflow = ''; menuBtn.setAttribute('aria-expanded', 'false'); };

      menuBtn.addEventListener('click', open);
      close && close.addEventListener('click', shut);
      menu.addEventListener('click', e => { if (e.target === menu) shut(); });

      document.addEventListener('keydown', e => { if (e.key === 'Escape') shut(); });
    },

    // ── SCROLL REVEAL ────────────────────────────────────────
    scrollReveal() {
      const els = document.querySelectorAll('.ck-reveal');
      if (!els.length || !window.IntersectionObserver) {
        els.forEach(el => el.classList.add('revealed'));
        return;
      }

      const io = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
            io.unobserve(entry.target);
          }
        });
      }, { threshold: 0.08, rootMargin: '0px 0px -32px 0px' });

      els.forEach(el => io.observe(el));
    },

    // ── HERO PARALLAX ────────────────────────────────────────
    parallax() {
      const media = document.querySelector('.ck-hero__media');
      if (!media) return;
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      if (window.innerWidth < 768) return;

      const hero = media.closest('.ck-hero');
      let ticking = false;

      window.addEventListener('scroll', () => {
        if (!ticking) {
          requestAnimationFrame(() => {
            const y = window.scrollY;
            if (y < hero.offsetHeight * 1.5) {
              media.style.transform = `translateY(${y * 0.28}px)`;
            }
            ticking = false;
          });
          ticking = true;
        }
      }, { passive: true });
    },

    // ── SIGNATURE GALLERY ────────────────────────────────────
    gallery() {
      document.querySelectorAll('.ck-signature__gallery').forEach(gallery => {
        const imgs  = gallery.querySelectorAll('[data-gallery-img]');
        const dots  = gallery.querySelectorAll('.ck-signature__dot');
        let current = 0;

        if (!imgs.length) return;

        dots.forEach((dot, i) => {
          dot.addEventListener('click', () => {
            imgs[current].style.opacity = '0';
            dots[current].classList.remove('active');
            current = i;
            imgs[current].style.opacity = '1';
            dots[current].classList.add('active');
          });
        });
      });

      // Product page thumbnails
      const thumbs = document.querySelectorAll('.ck-product-gallery__thumb');
      thumbs.forEach(thumb => {
        thumb.addEventListener('click', () => {
          thumbs.forEach(t => { t.classList.remove('active'); t.setAttribute('aria-pressed', 'false'); });
          thumb.classList.add('active');
          thumb.setAttribute('aria-pressed', 'true');
          const main = document.getElementById('featured-img');
          if (main) { main.src = thumb.dataset.src; main.alt = thumb.dataset.alt || ''; }
        });
      });
    },

    // ── ACCORDION ────────────────────────────────────────────
    accordion() {
      document.querySelectorAll('.ck-accordion-trigger').forEach(trigger => {
        trigger.addEventListener('click', () => {
          const item = trigger.closest('.ck-accordion-item');
          const expanded = trigger.getAttribute('aria-expanded') === 'true';
          trigger.setAttribute('aria-expanded', !expanded);
          item.classList.toggle('open', !expanded);
        });
      });
    },

    // ── CART DRAWER ──────────────────────────────────────────
    cartDrawer() {
      const overlay = document.querySelector('.ck-cart-overlay');
      const drawer  = document.querySelector('.ck-cart-drawer');
      const closeBtn= document.querySelector('.ck-cart-drawer__close');

      if (!drawer) return;

      const openCart  = () => { drawer.classList.add('open'); overlay && overlay.classList.add('open'); document.body.style.overflow = 'hidden'; };
      const closeCart = () => { drawer.classList.remove('open'); overlay && overlay.classList.remove('open'); document.body.style.overflow = ''; };

      // Open via CK header cart icon
      document.querySelectorAll('[data-open-cart]').forEach(btn => btn.addEventListener('click', openCart));
      closeBtn && closeBtn.addEventListener('click', closeCart);
      overlay  && overlay.addEventListener('click', closeCart);
      document.addEventListener('keydown', e => { if (e.key === 'Escape') closeCart(); });

      // Qty controls in CK cart drawer
      document.querySelectorAll('.ck-qty-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
          const item    = btn.closest('.ck-cart-item');
          const key     = item?.dataset.lineKey;
          const valEl   = item?.querySelector('.ck-qty-value');
          const current = parseInt(valEl?.textContent || '1');
          const delta   = btn.dataset.action === 'plus' ? 1 : -1;
          const newQty  = Math.max(0, current + delta);

          if (!key) return;

          try {
            const res = await fetch('/cart/change.js', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ id: key, quantity: newQty })
            });
            const cart = await res.json();

            if (newQty === 0) {
              item.remove();
            } else if (valEl) {
              valEl.textContent = newQty;
            }

            this.updateCartUI(cart);
          } catch (e) {
            console.warn('Cart update failed', e);
          }
        });
      });
    },

    // ── CART COUNT SYNC ──────────────────────────────────────
    cartCount() {
      const countEl    = document.getElementById('cart-count');
      const countBadge = document.querySelector('.ck-header__cart-count');

      const syncCount = async () => {
        try {
          const res  = await fetch('/cart.js');
          const cart = await res.json();
          this.updateCartUI(cart);
        } catch (e) {}
      };

      // Sync on page load
      syncCount();

      // Listen for Shopify cart events
      document.addEventListener('cart:updated', syncCount);
    },

    updateCartUI(cart) {
      const count    = cart.item_count || 0;
      const countEl  = document.getElementById('cart-count');
      const badge    = document.querySelector('.ck-header__cart-count');
      const mobileEl = document.getElementById('mobile-cart-count');
      const totalEl  = document.getElementById('mobile-cart-total');
      const subtotalEl = document.querySelector('.ck-cart-drawer__subtotal-amount');

      if (countEl) countEl.textContent = count;
      if (mobileEl) mobileEl.textContent = count;
      if (totalEl) totalEl.textContent = cart.total_price ? (cart.total_price / 100).toFixed(2) + ' AED' : '';
      if (subtotalEl) subtotalEl.textContent = count > 0 ? (cart.total_price / 100).toFixed(2) + ' AED' : '';

      if (badge) {
        badge.textContent = count;
        badge.classList.toggle('visible', count > 0);
      }
    }

  };

  // Init
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => CK.init());
  } else {
    CK.init();
  }

  window.CottonKey = CK;

})();
